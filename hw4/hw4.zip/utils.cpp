#include <vector>
#include <iostream>

using namespace std;


void loop_vect(vector<int> vect){
    for(auto val : vect){
        cout << val;
    }
}